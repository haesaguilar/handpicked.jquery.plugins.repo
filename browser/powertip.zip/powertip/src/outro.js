/**
 * PowerTip Outro
 *
 * @fileoverview  Closing lines for dist version.
 * @link          http://stevenbenner.github.com/jquery-powertip/
 * @author        Steven Benner (http://stevenbenner.com/)
 * @requires      jQuery 1.7+
 */

}(jQuery, window));
